<footer class="footer">
    <div class="container footer-content">
        <div class="footer-links">
            <a href="aboutus_polices_terms.html#about-us-title">About Us</a>
            <a href="aboutus_polices_terms.html#terms-title">Terms of Use</a>
            <a href="aboutus_polices_terms.html#privacy-policy-title">Privacy Policy</a>
            <a href="aboutus_polices_terms.html#section2">Sitemap</a>
        </div>
        <div class="copyright">
            &copy; 2024 UnitConverters.net. All rights reserved.
        </div>
    </div>
</footer>
