<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Collapsible Vertical Menu</title>
    <link rel="stylesheet" href="css/drawer_menu.css" />
</head>
<body>
    <div class="container">
        <h1 class="all-conversion_header">All Conversions</h1>
        <div class="menu">
            <!-- Time -->
            <details>
                <summary>Time</summary>
                <ul class="conversion-list">
                    <li><a href="#">Seconds</a></li>
                    <li><a href="#">Minutes</a></li>
                    <li><a href="#">Hours</a></li>
                    <li><a href="#">Days</a></li>
                    <li><a href="#">Weeks</a></li>
                    <li><a href="#">Months</a></li>
                    <li><a href="#">Years</a></li>
                    <li><a href="#">Decades</a></li>
                    <li><a href="#">Centuries</a></li>
                </ul>
            </details>

            <!-- Digital Storage -->
            <details>
                <summary>Digital Storage</summary>
                <ul class="conversion-list">
                    <li><a href="#">Bits</a></li>
                    <li><a href="#">Bytes</a></li>
                    <li><a href="#">Kilobytes</a></li>
                    <li><a href="#">Megabytes</a></li>
                    <li><a href="#">Gigabytes</a></li>
                    <li><a href="#">Terabytes</a></li>
                    <li><a href="#">Petabytes</a></li>
                    <li><a href="#">Exabytes</a></li>
                </ul>
            </details>

            <!-- Currency -->
            <details>
                <summary>Currency</summary>
                <ul class="conversion-list">
                    <li><a href="#">US Dollar [USD]</a></li>
                    <li><a href="#">Euro [EUR]</a></li>
                    <li><a href="#">British Pound [GBP]</a></li>
                    <li><a href="#">Indian Rupee [INR]</a></li>
                    <li><a href="#">Japanese Yen [JPY]</a></li>
                    <li><a href="#">Mauritian Rupee [MUR]</a></li>
                </ul>
            </details>

            <!-- Cooking -->
            <details>
                <summary>Cooking</summary>
                <ul class="conversion-list">
                    <li><a href="#">Cups</a></li>
                    <li><a href="#">Tablespoons</a></li>
                    <li><a href="#">Teaspoons</a></li>
                    <li><a href="#">Milliliters</a></li>
                    <li><a href="#">Liters</a></li>
                    <li><a href="#">Grams</a></li>
                    <li><a href="#">Ounces</a></li>
                </ul>
            </details>

            <!-- Energy / Power -->
            <details>
                <summary>Energy / Power</summary>
                <ul class="conversion-list">
                    <li><a href="#">Joules</a></li>
                    <li><a href="#">Kilojoules</a></li>
                    <li><a href="#">Calories</a></li>
                    <li><a href="#">Kilocalories</a></li>
                    <li><a href="#">Watt-hours</a></li>
                    <li><a href="#">Kilowatt-hours</a></li>
                    <li><a href="#">BTU</a></li>
                    <li><a href="#">Horsepower</a></li>
                </ul>
            </details>

            <!-- Volume / Capacity -->
            <details>
                <summary>Volume / Capacity</summary>
                <ul class="conversion-list">
                    <li><a href="#">Milliliters</a></li>
                    <li><a href="#">Liters</a></li>
                    <li><a href="#">Cups</a></li>
                    <li><a href="#">Pints</a></li>
                    <li><a href="#">Quarts</a></li>
                    <li><a href="#">Gallons</a></li>
                    <li><a href="#">Cubic Inches</a></li>
                    <li><a href="#">Cubic Feet</a></li>
                </ul>
            </details>

            <!-- Area -->
            <details>
                <summary>Area</summary>
                <ul class="conversion-list">
                    <li><a href="#">Square Millimeters</a></li>
                    <li><a href="#">Square Centimeters</a></li>
                    <li><a href="#">Square Meters</a></li>
                    <li><a href="#">Square Kilometers</a></li>
                    <li><a href="#">Square Inches</a></li>
                    <li><a href="#">Square Feet</a></li>
                    <li><a href="#">Square Yards</a></li>
                    <li><a href="#">Acres</a></li>
                    <li><a href="#">Hectares</a></li>
                </ul>
            </details>

            <!-- Speed -->
            <details>
                <summary>Speed</summary>
                <ul class="conversion-list">
                    <li><a href="#">Meters per Second</a></li>
                    <li><a href="#">Kilometers per Hour</a></li>
                    <li><a href="#">Miles per Hour</a></li>
                    <li><a href="#">Feet per Second</a></li>
                    <li><a href="#">Knots</a></li>
                    <li><a href="#">Mach</a></li>
                </ul>
            </details>

            <!-- Length -->
            <details>
                <summary>Length</summary>
                <ul class="conversion-list">
                    <li><a href="#">Millimeters</a></li>
                    <li><a href="#">Centimeters</a></li>
                    <li><a href="#">Meters</a></li>
                    <li><a href="#">Kilometers</a></li>
                    <li><a href="#">Inches</a></li>
                    <li><a href="#">Feet</a></li>
                    <li><a href="#">Yards</a></li>
                    <li><a href="#">Miles</a></li>
                    <li><a href="#">Nautical Miles</a></li>
                </ul>
            </details>

            <!-- Weight / Mass -->
            <details>
                <summary>Weight / Mass</summary>
                <ul class="conversion-list">
                    <li><a href="#">Milligrams</a></li>
                    <li><a href="#">Grams</a></li>
                    <li><a href="#">Kilograms</a></li>
                    <li><a href="#">Metric Tons</a></li>
                    <li><a href="#">Ounces</a></li>
                    <li><a href="#">Pounds</a></li>
                    <li><a href="#">Stones</a></li>
                </ul>
            </details>

            <!-- Temperature -->
            <details>
                <summary>Temperature</summary>
                <ul class="conversion-list">
                    <li><a href="#">Celsius</a></li>
                    <li><a href="#">Fahrenheit</a></li>
                    <li><a href="#">Kelvin</a></li>
                    <li><a href="#">Rankine</a></li>
                </ul>
            </details>

            <!-- Math & Number Conversions -->
            <details>
                <summary>Math & Number Conversions</summary>
                <ul class="conversion-list">
                    <li><a href="#">Fractions</a></li>
                    <li><a href="#">Decimals</a></li>
                    <li><a href="#">Percentages</a></li>
                    <li><a href="#">Scientific Notation</a></li>
                    <li><a href="#">Binary</a></li>
                    <li><a href="#">Octal</a></li>
                    <li><a href="#">Decimal</a></li>
                    <li><a href="#">Hexadecimal</a></li>
                    <li><a href="#">Roman Numerals</a></li>
                </ul>
            </details>

            <!-- Chemistry & Science -->
            <details>
                <summary>Chemistry & Science</summary>
                <ul class="conversion-list">
                    <li><a href="#">Moles</a></li>
                    <li><a href="#">Grams</a></li>
                    <li><a href="#">Atomic Mass Units</a></li>
                    <li><a href="#">ppm</a></li>
                    <li><a href="#">mol/L</a></li>
                    <li><a href="#">g/L</a></li>
                </ul>
            </details>

            <!-- Calendar & Timezone -->
            <details>
                <summary>Calendar & Timezone</summary>
                <ul class="conversion-list">
                    <li><a href="#">Gregorian Calendar</a></li>
                    <li><a href="#">Julian Calendar</a></li>
                    <li><a href="#">UNIX Timestamp</a></li>
                    <li><a href="#">UTC</a></li>
                    <li><a href="#">Local Timezones</a></li>
                </ul>
            </details>

            <!-- Engineering / Physics -->
            <details>
                <summary>Engineering / Physics</summary>
                <ul class="conversion-list">
                    <li><a href="#">Newtons</a></li>
                    <li><a href="#">Joules</a></li>
                    <li><a href="#">Torque (Nm)</a></li>
                    <li><a href="#">Pressure (Pa, PSI, Bar)</a></li>
                    <li><a href="#">Tesla</a></li>
                    <li><a href="#">Gauss</a></li>
                </ul>
            </details>

            <!-- Finance / Economics -->
            <details>
                <summary>Finance / Economics</summary>
                <ul class="conversion-list">
                    <li><a href="#">Annual Interest Rate</a></li>
                    <li><a href="#">Monthly Interest Rate</a></li>
                    <li><a href="#">APR</a></li>
                    <li><a href="#">APY</a></li>
                    <li><a href="#">Loan Payment</a></li>
                    <li><a href="#">Inflation Rate</a></li>
                </ul>
            </details>

            <!-- Health & Fitness -->
            <details>
                <summary>Health & Fitness</summary>
                <ul class="conversion-list">
                    <li><a href="#">BMI</a></li>
                    <li><a href="#">BMR</a></li>
                    <li><a href="#">Calories Burned</a></li>
                    <li><a href="#">Body Fat Percentage</a></li>
                    <li><a href="#">Macronutrient Ratios</a></li>
                </ul>
            </details>

            <!-- Construction / Architecture -->
            <details>
                <summary>Construction / Architecture</summary>
                <ul class="conversion-list">
                    <li><a href="#">Board Feet</a></li>
                    <li><a href="#">Concrete Volume</a></li>
                    <li><a href="#">Roof Pitch</a></li>
                    <li><a href="#">Rebar Sizes</a></li>
                </ul>
            </details>

            <!-- Computer / IT -->
            <details>
                <summary>Computer / IT</summary>
                <ul class="conversion-list">
                    <li><a href="#">Bandwidth (MBps, Mbps)</a></li>
                    <li><a href="#">Data Rate</a></li>
                    <li><a href="#">Baud</a></li>
                    <li><a href="#">DPI</a></li>
                    <li><a href="#">PPI</a></li>
                    <li><a href="#">Aspect Ratio</a></li>
                </ul>
            </details>

            <!-- Frequency / Radio / Signal -->
            <details>
                <summary>Frequency / Radio / Signal</summary>
                <ul class="conversion-list">
                    <li><a href="#">Hertz</a></li>
                    <li><a href="#">Kilohertz</a></li>
                    <li><a href="#">Megahertz</a></li>
                    <li><a href="#">Gigahertz</a></li>
                    <li><a href="#">Wavelength</a></li>
                    <li><a href="#">dBm</a></li>
                    <li><a href="#">Signal-to-Noise Ratio</a></li>
                </ul>
            </details>

            <!-- Date & Age -->
            <details>
                <summary>Date & Age</summary>
                <ul class="conversion-list">
                    <li><a href="#">Date Duration</a></li>
                    <li><a href="#">Age</a></li>
                    <li><a href="#">Countdown Timer</a></li>
                    <li><a href="#">Days Between Dates</a></li>
                </ul>
            </details>
        </div>
    </div>
</body>
</html>
